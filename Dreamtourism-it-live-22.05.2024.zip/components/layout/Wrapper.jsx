const Wrapper = ({ children }) => {
    return <>{children}</>;
  };
  
  export default Wrapper;